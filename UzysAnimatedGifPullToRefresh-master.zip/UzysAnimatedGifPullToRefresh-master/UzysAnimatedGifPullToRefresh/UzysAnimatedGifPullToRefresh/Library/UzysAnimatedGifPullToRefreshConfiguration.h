//
//  NSObject_UzysAnimatedGifPullToRefreshConfiguration.h
//  UzysAnimatedGifPullToRefresh
//
//  Created by Uzysjung on 2014. 4. 16..
//  Copyright (c) 2014년 Uzys. All rights reserved.
//

#define initialPulltoRefreshThreshold 50.0
#define StartPosition 10.0
#define ProgressImageMargin 2.0
#define LoadingImageMargin 2.0