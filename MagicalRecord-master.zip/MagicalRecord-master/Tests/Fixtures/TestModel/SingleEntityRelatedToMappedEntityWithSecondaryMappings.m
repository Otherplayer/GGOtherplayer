#import "SingleEntityRelatedToMappedEntityWithSecondaryMappings.h"

@interface SingleEntityRelatedToMappedEntityWithSecondaryMappings ()

// Private interface goes here.

@end

@implementation SingleEntityRelatedToMappedEntityWithSecondaryMappings

// Custom logic goes here.

@end
