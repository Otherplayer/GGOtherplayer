#import "ConcreteRelatedEntity.h"

@interface ConcreteRelatedEntity ()

// Private interface goes here.

@end

@implementation ConcreteRelatedEntity

// Custom logic goes here.

@end
