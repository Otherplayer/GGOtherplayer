#import "_ConcreteRelatedEntity.h"

@interface ConcreteRelatedEntity : _ConcreteRelatedEntity {}
// Custom logic goes here.
@end
