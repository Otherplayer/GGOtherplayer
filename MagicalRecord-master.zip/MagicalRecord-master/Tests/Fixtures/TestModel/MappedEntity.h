#import "_MappedEntity.h"

@interface MappedEntity : _MappedEntity {}
// Custom logic goes here.
@end
