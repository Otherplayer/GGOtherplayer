#import "_SingleEntityRelatedToMappedEntityUsingDefaults.h"

@interface SingleEntityRelatedToMappedEntityUsingDefaults : _SingleEntityRelatedToMappedEntityUsingDefaults {}
// Custom logic goes here.
@end
