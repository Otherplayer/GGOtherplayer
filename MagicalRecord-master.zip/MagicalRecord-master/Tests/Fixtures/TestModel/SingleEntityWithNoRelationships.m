#import "SingleEntityWithNoRelationships.h"

@interface SingleEntityWithNoRelationships ()

// Private interface goes here.

@end

@implementation SingleEntityWithNoRelationships

// Custom logic goes here.

@end
