#import "SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey.h"

@interface SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey ()

// Private interface goes here.

@end

@implementation SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey

// Custom logic goes here.

@end
