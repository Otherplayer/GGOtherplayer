//
//  Created by Tony Arnold on 11/04/2014.
//  Copyright (c) 2014 Magical Panda Software LLC. All rights reserved.
//

#import "EntityWithoutEntityNameMethod.h"

@implementation EntityWithoutEntityNameMethod

@end
