// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to DifferentClassNameMapping.h instead.

#import <CoreData/CoreData.h>

@interface DifferentClassNameMappingID : NSManagedObjectID {}
@end

@interface _DifferentClassNameMapping : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (DifferentClassNameMappingID*)objectID;

@end

@interface _DifferentClassNameMapping (CoreDataGeneratedPrimitiveAccessors)

@end
