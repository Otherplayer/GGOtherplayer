#import "DifferentClassNameMapping.h"

@interface DifferentClassNameMapping ()

// Private interface goes here.

@end

@implementation DifferentClassNameMapping

// Custom logic goes here.

@end
