#import "_SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey.h"

@interface SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey : _SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey {}
// Custom logic goes here.
@end
