#import "SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey.h"

@interface SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey ()

// Private interface goes here.

@end

@implementation SingleEntityRelatedToManyMappedEntitiesUsingMappedPrimaryKey

// Custom logic goes here.

@end
