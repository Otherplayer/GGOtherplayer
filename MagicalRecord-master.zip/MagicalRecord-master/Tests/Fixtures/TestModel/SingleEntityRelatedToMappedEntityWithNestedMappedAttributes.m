#import "SingleEntityRelatedToMappedEntityWithNestedMappedAttributes.h"

@interface SingleEntityRelatedToMappedEntityWithNestedMappedAttributes ()

// Private interface goes here.

@end

@implementation SingleEntityRelatedToMappedEntityWithNestedMappedAttributes

// Custom logic goes here.

@end
