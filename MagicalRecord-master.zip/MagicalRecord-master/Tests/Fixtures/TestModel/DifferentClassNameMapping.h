#import "_DifferentClassNameMapping.h"

@interface DifferentClassNameMapping : _DifferentClassNameMapping {}
// Custom logic goes here.
@end
