#import "_SingleRelatedEntity.h"

@interface SingleRelatedEntity : _SingleRelatedEntity {}
// Custom logic goes here.
@end
