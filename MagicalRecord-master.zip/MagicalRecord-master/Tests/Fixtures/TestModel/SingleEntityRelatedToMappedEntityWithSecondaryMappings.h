#import "_SingleEntityRelatedToMappedEntityWithSecondaryMappings.h"

@interface SingleEntityRelatedToMappedEntityWithSecondaryMappings : _SingleEntityRelatedToMappedEntityWithSecondaryMappings {}
// Custom logic goes here.
@end
