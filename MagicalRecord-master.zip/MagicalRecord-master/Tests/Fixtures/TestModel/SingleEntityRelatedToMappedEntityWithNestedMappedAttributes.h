#import "_SingleEntityRelatedToMappedEntityWithNestedMappedAttributes.h"

@interface SingleEntityRelatedToMappedEntityWithNestedMappedAttributes : _SingleEntityRelatedToMappedEntityWithNestedMappedAttributes {}
// Custom logic goes here.
@end
