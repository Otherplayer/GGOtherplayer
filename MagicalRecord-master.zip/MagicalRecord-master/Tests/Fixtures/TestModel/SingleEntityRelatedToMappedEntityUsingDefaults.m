#import "SingleEntityRelatedToMappedEntityUsingDefaults.h"

@interface SingleEntityRelatedToMappedEntityUsingDefaults ()

// Private interface goes here.

@end

@implementation SingleEntityRelatedToMappedEntityUsingDefaults

// Custom logic goes here.

@end
