#import "_AbstractRelatedEntity.h"

@interface AbstractRelatedEntity : _AbstractRelatedEntity {}
// Custom logic goes here.
@end
