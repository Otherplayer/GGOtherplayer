#import "_SingleEntityWithNoRelationships.h"

@interface SingleEntityWithNoRelationships : _SingleEntityWithNoRelationships {}
// Custom logic goes here.
@end
