#import "SingleRelatedEntity.h"

@interface SingleRelatedEntity ()

// Private interface goes here.

@end

@implementation SingleRelatedEntity

// Custom logic goes here.

@end
