#import "AbstractRelatedEntity.h"

@interface AbstractRelatedEntity ()

// Private interface goes here.

@end

@implementation AbstractRelatedEntity

// Custom logic goes here.

@end
