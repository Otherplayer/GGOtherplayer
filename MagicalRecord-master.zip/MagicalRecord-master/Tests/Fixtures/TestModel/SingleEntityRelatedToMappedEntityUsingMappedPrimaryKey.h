#import "_SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey.h"

@interface SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey : _SingleEntityRelatedToMappedEntityUsingMappedPrimaryKey {}
// Custom logic goes here.
@end
