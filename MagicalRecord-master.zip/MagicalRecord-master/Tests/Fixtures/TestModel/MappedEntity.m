#import "MappedEntity.h"

@interface MappedEntity ()

// Private interface goes here.

@end

@implementation MappedEntity

// Custom logic goes here.

@end
