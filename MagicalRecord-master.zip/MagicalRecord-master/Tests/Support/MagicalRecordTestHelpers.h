//
//  Copyright (c) 2015 Magical Panda Software LLC. All rights reserved.

#import <Foundation/Foundation.h>

@interface MagicalRecordTestHelpers : NSObject

+ (BOOL)removeStoreFilesForStoreAtURL:(NSURL *)storeURL;

@end
