//
//  main.m
//  Recipes
//
//  Created by Saul Mora on 5/19/13.
//
//

#import <UIKit/UIKit.h>

#import "MGPRecipesAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MGPRecipesAppDelegate class]));
    }
}
