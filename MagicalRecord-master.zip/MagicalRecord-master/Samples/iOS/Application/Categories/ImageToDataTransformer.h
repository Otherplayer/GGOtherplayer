//
//  ImageToDataTransformer.h
//  MagicalRecordRecipes
//
//  Created by Saul Mora on 5/19/13.
//
//

#import <Foundation/Foundation.h>

@interface ImageToDataTransformer : NSValueTransformer

@end
