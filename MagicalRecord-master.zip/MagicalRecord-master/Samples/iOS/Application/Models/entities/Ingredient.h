#import "_Ingredient.h"

@interface Ingredient : _Ingredient {}
// Custom logic goes here.
@end
