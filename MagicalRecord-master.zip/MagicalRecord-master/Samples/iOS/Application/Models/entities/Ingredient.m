#import "Ingredient.h"


@interface Ingredient ()

// Private interface goes here.

@end


@implementation Ingredient

// Custom logic goes here.

@end
