#import "Recipe.h"


@interface Recipe ()

// Private interface goes here.

@end


@implementation Recipe

// Custom logic goes here.

@end
