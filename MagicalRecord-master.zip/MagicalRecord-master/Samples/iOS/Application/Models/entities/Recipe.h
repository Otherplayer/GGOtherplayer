#import "_Recipe.h"

@interface Recipe : _Recipe {}
// Custom logic goes here.
@end
