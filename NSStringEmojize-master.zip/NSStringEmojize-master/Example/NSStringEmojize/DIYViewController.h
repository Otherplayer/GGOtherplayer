//
//  DIYViewController.h
//  NSStringEmojize
//
//  Created by Jonathan Beilin on 1/30/13.
//  Copyright (c) 2013 DIY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DIYViewController : UIViewController

@end
