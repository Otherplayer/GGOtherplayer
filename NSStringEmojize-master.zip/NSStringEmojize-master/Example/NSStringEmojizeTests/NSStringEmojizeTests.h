//
//  NSStringEmojizeTests.h
//  NSStringEmojizeTests
//
//  Created by Jonathan Beilin on 1/30/13.
//  Copyright (c) 2013 DIY. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NSStringEmojizeTests : SenTestCase

@end
