//
//  UITableViewCell+NIB.h
//  IOS-Categories
//
//  Created by Jakey on 14/11/19.
//  Copyright (c) 2014年 jakey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (NIB)
+(UINib*)nib;
@end
