//
//  ContactDB.m
//  CoreData-sqlite3
//
//  Created by guoxiaodong on 13-6-4.
//  Copyright (c) 2013年 chinasofti. All rights reserved.
//

#import "ContactDB.h"
#import "Contact.h"
#import "ViewController.h"

@implementation ContactDB
- (void)dealloc
{
    sqlite3_close(_dataBase);
    [super dealloc];
}
//
-(id)init
{
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex: 0];
    NSString * plistPath = [docDir stringByAppendingPathComponent:FILE_NAME_CONTACTLIST_DB];

    self = [super init];
    int rc = sqlite3_open([plistPath cStringUsingEncoding:NSUTF8StringEncoding], &_dataBase);
	if(rc == SQLITE_OK) [self CreateTable];
    return self;
}
//
-(int) CreateTable
{
	int			ret = 0;
	char		* sql;
	char		* zErrMsg = 0;
	//create table
	sql = "create table [Contact] ("
    "[id]                   integer PRIMARY KEY,"
    "[userID]               text,"
    "[localName]            text ,"
    "[uri]                  text,"
    "[onlineNotify]         integer,"
    "[blocked]              integer,"
    "[type]                 integer,"
    "[relationStatus]   	integer,"
    "[birthdayPermission]   integer,"
    "[mailPermission]   	integer,"
    "[mobilePermission]   	integer,"
    "[presencePermission]   integer,"
    "[sid]                  text,"
    "[nickname]             text,"
    "[impresa]              text,"
    "[portraitCrc]          text,"
    "[mobileNumber]         text,"
    "[deviceCaps]           text,"
    "[carrier]              text,"
    "[isMember]             integer,"
    "[isSmsOnline]          integer,"
    "[carrierStatus]        integer,"
    "[basicServiceStatus]   integer,"
    "[state]                integer,"
    "[deviecType]           integer,"
    "[pushDeviceType]   	integer,"
    "[sortKey]              text);";
	ret = sqlite3_exec(_dataBase, sql, 0, 0, &zErrMsg);
	sqlite3_free(zErrMsg);
	//
	return ret;
}
//
-(void) save:(NSMutableArray*) aContactArray
{
	int  rc = 0;
	char				* sql;
	char				* zErrMsg = 0;
	sqlite3_stmt		* stmt;
	//
	sql = "insert into Contact values(NULL,?,?,?,?,    ?,?,?,?,    ?,?,?,?,    ?,?,?,?,    ?,?,?,?,    ?,?,?,?,    ?,?);";
	rc = sqlite3_prepare_v2(_dataBase,sql,-1,&stmt, NULL);
	if(rc != SQLITE_OK)
	{
		sqlite3_finalize(stmt);
		return ;
	}
    //
	rc = sqlite3_exec(_dataBase, "begin;", NULL, NULL, &zErrMsg);
	sqlite3_free(zErrMsg);
	for(Contact* contact in aContactArray )
	{
		int index = 0;
		[self BindStmtContact:&index :stmt :contact];
        
		rc = sqlite3_step(stmt);
		if(rc != SQLITE_DONE)
		{
			sqlite3_finalize(stmt);
			break;
		}
		sqlite3_reset(stmt);
	}
	rc = sqlite3_exec(_dataBase, "commit;", NULL, NULL, &zErrMsg);
	sqlite3_free(zErrMsg);
	sqlite3_finalize(stmt);
}
//
-(void)loadContact
{
	int ret=0;
	char					* sql = 0;
	sqlite3_stmt			* stmt;
    
	sql = "select * from Contact ;";
	ret = sqlite3_prepare_v2(_dataBase, sql, -1, &stmt, NULL);
	if(ret != SQLITE_OK)
	{
		sqlite3_finalize(stmt);
		return ;
	}
	while(sqlite3_step(stmt) ==  SQLITE_ROW)
	{
		int index = -1;
		Contact* iContact = [[Contact alloc]init];
		iContact.dbID           = sqlite3_column_int(stmt, ++index);
		iContact.userID         = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
		iContact.localName      = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSUTF8StringEncoding];
        iContact.uri            = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
		iContact.onlineNotify   = sqlite3_column_int(stmt, ++index);
        iContact.blocked        = sqlite3_column_int(stmt, ++index);
        iContact.type           = sqlite3_column_int(stmt, ++index);
        iContact.relationStatus = sqlite3_column_int(stmt, ++index);
        iContact.birthdayPermission = sqlite3_column_int(stmt, ++index);
        iContact.mailPermission = sqlite3_column_int(stmt, ++index);
        iContact.mobileNumber   = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.presencePermission = sqlite3_column_int(stmt, ++index);
		iContact.sid            = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.nickName       = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSUTF8StringEncoding];
        iContact.impresa        = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSUTF8StringEncoding];
		iContact.portraitCrc    = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.mobileNumber   = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.deviceCaps     = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.carrier        = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSASCIIStringEncoding];
        iContact.isMember       = sqlite3_column_int(stmt, ++index);
        iContact.carrierStatus  = sqlite3_column_int(stmt, ++index);
        iContact.state          = sqlite3_column_int(stmt, ++index);
        iContact.deviceType     = sqlite3_column_int(stmt, ++index);
        iContact.pushdeviceType = sqlite3_column_int(stmt, ++index);
        iContact.sortKey        = [NSString stringWithCString:(char*)sqlite3_column_text(stmt, ++index) encoding:NSUTF8StringEncoding];
		[vc addContact:iContact];
		[iContact release];
	}
	ret = sqlite3_finalize(stmt);
}
/*
 参数index无效，这是为了测试 程序性能加进来的，用于说明。
 使用++（*index）要比局部变量++_index慢，因为++（*index）进行了存储器操作（确切的说是高速缓存的操作），而++index只是寄存器的操作。 
 */
-(void)BindStmtContact:(int*)index :(sqlite3_stmt*) stmt :(Contact*) aContact
{
    int _index =0;
    sqlite3_bind_text	(stmt, ++_index, [aContact.userID cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.localName cStringUsingEncoding:NSUTF8StringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.uri cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
	sqlite3_bind_int	(stmt, ++_index, aContact.onlineNotify);
    sqlite3_bind_int	(stmt, ++_index, aContact.blocked);
    sqlite3_bind_int	(stmt, ++_index, aContact.type);
    sqlite3_bind_int	(stmt, ++_index, aContact.relationStatus);
    sqlite3_bind_int	(stmt, ++_index, aContact.birthdayPermission);
    sqlite3_bind_int	(stmt, ++_index, aContact.mailPermission);
    sqlite3_bind_text	(stmt, ++_index, [aContact.mobileNumber cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_int	(stmt, ++_index, aContact.presencePermission);
    sqlite3_bind_text	(stmt, ++_index, [aContact.sid cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.nickName cStringUsingEncoding:NSUTF8StringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.impresa cStringUsingEncoding:NSUTF8StringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.portraitCrc cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.mobileNumber cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.deviceCaps cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_text	(stmt, ++_index, [aContact.carrier cStringUsingEncoding:NSASCIIStringEncoding], -1, SQLITE_STATIC);
    sqlite3_bind_int	(stmt, ++_index, aContact.isMember);
    sqlite3_bind_int	(stmt, ++_index, aContact.carrierStatus);
    sqlite3_bind_int	(stmt, ++_index, aContact.state);
    sqlite3_bind_int	(stmt, ++_index, aContact.deviceType);
    sqlite3_bind_int	(stmt, ++_index, aContact.pushdeviceType);
    sqlite3_bind_text	(stmt, ++_index, [aContact.sortKey cStringUsingEncoding:NSUTF8StringEncoding], -1,SQLITE_STATIC);
}
@end
