//
//  ViewController.m
//  CoreData-sqlite3
//
//  Created by guoxiaodong on 13-6-3.
//  Copyright (c) 2013年 chinasofti. All rights reserved.
//

#import "ViewController.h"
#import "ContactDB.h"
#define KEY_CONTACTLIST_DATA @"coredata"
#define FILE_NAME_CONTACTLIST_ACHIEVE @"coredata.plist"
typedef void (^DataOperatorBlock)(void);

@interface ViewController ()
-(void) clearData;
-(void) saveCoreData;
@end
int readTimes   = 0;
int writeTimes  = 0;
NSTimeInterval sqlite3WriteAccTime=0.0f;
NSTimeInterval coreDataWriteAccTime=0.0f;
NSTimeInterval sqlite3ReadAccTime=0.0f;
NSTimeInterval coreDataReadAccTime=0.0f;
@implementation ViewController
-(void)dealloc
{
    [self clearData];
    [_uriArray          release];
    [_coredataRead      release];
    [_coredataReadAvg   release];
    [_coredataWrite     release];
    [_coredataWriteAvg  release];
    [_sqlite3Read       release];
    [_sqlite3ReadAvg    release];
    [_sqlite3Write      release];
    [_sqlite3WriteAvg   release];
    [_loopTimes         release];
    [writeTimesLabel    release];
    [readTimesLabel     release];
    //
    [super dealloc];
}
//
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    _uriArray       = [[NSMutableArray alloc]init];
    vc = self;
}
//
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//
-(void)clearData
{
    [_uriArray removeAllObjects];
}
//
-(IBAction) writeData
{
    writeTimes ++;
    [self prepareData];
    //for coredata
    [self saveCoreData];
    //for sqlite3
    [self writeContactSqlite3];
    [writeTimesLabel setText:[NSString stringWithFormat:@"%d",writeTimes]];
}
//
-(IBAction) readData
{
    readTimes ++;
    [self loadSqlite3];
    [self loadCoreData];
    [readTimesLabel setText:[NSString stringWithFormat:@"%d",readTimes]];
}
//
-(IBAction) clearUIData
{
    readTimes           = 0;
    writeTimes          = 0;
    sqlite3WriteAccTime = 0.0f;
    coreDataWriteAccTime= 0.0f;
    sqlite3ReadAccTime  = 0.0f;
    coreDataReadAccTime = 0.0f;
    [_coredataRead      setText:@"0"];
    [_coredataReadAvg   setText:@"0"];
    [_coredataWrite     setText:@"0"];
    [_coredataWriteAvg  setText:@"0"];
    [_sqlite3Read       setText:@"0"];
    [_sqlite3ReadAvg    setText:@"0"];
    [_sqlite3Write      setText:@"0"];
    [_sqlite3WriteAvg   setText:@"0"];
    [writeTimesLabel    setText:@"0"];
    [readTimesLabel     setText:@"0"];
    
}
//
-(void) addContact:(Contact*) contact
{
    [_uriArray addObject:contact];
}
-(void)prepareData
{
    //1.prepare _uriDictionnary
    int loopsTimes = [_loopTimes.text intValue];
    if (loopsTimes<=0 ) {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"waring" message:@"输入正确的数值"delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"ok", nil];
        [alert show];
    }
    //2.clear dada first
    [self clearData];
    //3.loop
    for (int i=0; i<loopsTimes; i++) {
        Contact* temp = [[Contact alloc]init];
        temp.userID         = [NSString stringWithFormat:@"%9d",i];
        temp.localName      = @"我的昵称";
        temp.uri            = [NSString stringWithFormat:@"%9d",i];
        //temp.groupID        = @"1";
        temp.onlineNotify   = YES;
        temp.blocked        = NO;
        temp.type           = EFriend;
        temp.relationStatus = EConfirmed;
        temp.birthdayPermission = YES;
        temp.mailPermission = YES;
        temp.mobilePermission   = YES;
        temp.presencePermission = YES;
        temp.sid            = [NSString stringWithFormat:@"%9d",i];
        temp.nickName       = @"我昵称";
        temp.impresa        = @"今天是个好日子，心想的事儿都能成";
        temp.portraitCrc    = [NSString stringWithFormat:@"%9d",i];
        temp.mobileNumber   = i%5 == 0 ? @"13800138000":@"";
        temp.deviceCaps     = @"2b3422";
        temp.carrier        = @"CMCC";
        temp.isMember       = YES;
        temp.isSmsOnline    = YES;
        temp.carrierStatus  = ENormal;
        temp.basicServiceStatus   = EClose;
        temp.state          = EBasicValueOnline;
        temp.deviceType     = EBasicPushDeviceTypes_Mobile;
        temp.pushdeviceType = EBasicPushDeviceTypes_Mobile;
        temp.sortKey        = @"sortkey";
        //
        [_uriArray addObject:temp];
        [temp release];
    }
}
#pragma mark -- coredata --
-(NSTimeInterval) calculteTime:(DataOperatorBlock)block label:(UILabel*) label Title:(NSString*)title;
{
    NSTimeInterval time1 = [[NSDate date] timeIntervalSince1970];
    block();
    NSTimeInterval time2 = [[NSDate date] timeIntervalSince1970];//*1000000.0f;
    [label setText:[NSString stringWithFormat:@"%.4f秒",time2-time1]];
    NSLog(@"%@ = %.6f",title,time2-time1);
    return time2-time1;
}
-(void) loadSqlite3
{
    NSTimeInterval time = [self calculteTime:^(void){
        ContactDB *db = [[ContactDB alloc]init];
        [db loadContact];
        [db release];
    } label:_sqlite3Read Title:@"loadSqlite3"];
    [_sqlite3ReadAvg setText:[NSString stringWithFormat:@"%.4f秒",(sqlite3ReadAccTime+=time)/readTimes]];
}
//
-(void) writeContactSqlite3
{
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex: 0];
    NSString * dbPath = [docDir stringByAppendingPathComponent:FILE_NAME_CONTACTLIST_DB];
    [self deleteFile:dbPath];
    //
    NSTimeInterval time = [self calculteTime:^(void){
     ContactDB* db = [[ContactDB alloc]init];
     [db save:_uriArray];
        [db release];}
     label:_sqlite3Write Title:@"writeSqlite3"];
    [_sqlite3WriteAvg setText:[NSString stringWithFormat:@"%.4f秒",(sqlite3WriteAccTime+=time)/writeTimes]];
}
#pragma mark -- coredata --
//clear data first
-(void) loadCoreData
{
    //
    [self clearData];
    //prepare path
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex: 0];
    NSString * plistPath = [docDir stringByAppendingPathComponent:FILE_NAME_CONTACTLIST_ACHIEVE];
    NSDictionary * archieveDictionary = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    NSTimeInterval time = [self calculteTime:^(void){
    //load
    if(archieveDictionary != nil)
    {
        NSArray * contactListData = [archieveDictionary objectForKey:KEY_CONTACTLIST_DATA];
        // load contactList
        for ( NSData * data in contactListData )
        {
            NSKeyedUnarchiver *archiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
            Contact * theContact = [archiver decodeObjectForKey:@"Contact"];
            [archiver finishDecoding];
            [_uriArray addObject:theContact];
            [archiver release];
        }
    }
    }label:_coredataRead Title:@"coredateRead"];
    [_coredataReadAvg setText:[NSString stringWithFormat:@"%.4f秒",(coreDataReadAccTime+=time)/readTimes]];
}
//
-(void) saveCoreData
{
    NSTimeInterval time = [self calculteTime:^(void){
    //
    NSMutableArray * contactListData = [NSMutableArray arrayWithCapacity:[_uriArray count]];
    for (Contact * contact in _uriArray)
    {
        NSMutableData * plistData = [NSMutableData data];
        NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:plistData];
        [archiver encodeObject:contact forKey:@"Contact"];
        [archiver finishEncoding];
        [contactListData addObject:plistData];
        [archiver release];
    }
    //
	NSDictionary * archieveDictionary = [NSDictionary dictionaryWithObjectsAndKeys:contactListData,KEY_CONTACTLIST_DATA,nil];
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex: 0];
    NSString * plistPath = [docDir stringByAppendingPathComponent:FILE_NAME_CONTACTLIST_ACHIEVE];
    [archieveDictionary writeToFile:plistPath atomically:YES];
    } label:_coredataWrite Title:@"coredateWrite"];
    [_coredataWriteAvg setText:[NSString stringWithFormat:@"%.4f秒",(coreDataWriteAccTime += time)/writeTimes]];
}
//
-(void) deleteFile:(NSString *)filePath
{
    BOOL isExsit = [self fileIsExist:filePath];
    if (isExsit) {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
    }
}
//
-(BOOL)fileIsExist:(NSString*)filePath
{
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {
        return YES;
    }
    return NO;
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_loopTimes resignFirstResponder];//滑动时隐藏输入法
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_loopTimes resignFirstResponder];//滑动时隐藏输入法
}
@end
