//
//  AppDelegate.h
//  CoreData-sqlite3
//
//  Created by guoxiaodong on 13-6-3.
//  Copyright (c) 2013年 chinasofti. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
