//
//  ViewController.h
//  CoreData-sqlite3
//
//  Created by guoxiaodong on 13-6-3.
//  Copyright (c) 2013年 chinasofti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Contact.h"
@interface ViewController : UIViewController<UITextFieldDelegate>
{
    IBOutlet UILabel  *_coredataRead;
    IBOutlet UILabel  *_coredataReadAvg;
    IBOutlet UILabel  *_coredataWrite;
    IBOutlet UILabel  *_coredataWriteAvg;
    IBOutlet UILabel  *_sqlite3Read;
    IBOutlet UILabel  *_sqlite3ReadAvg;
    IBOutlet UILabel  *_sqlite3Write;
    IBOutlet UILabel  *_sqlite3WriteAvg;
    IBOutlet UITextField *_loopTimes;
    IBOutlet UILabel  *writeTimesLabel;
    IBOutlet UILabel  *readTimesLabel;
    //data
    NSMutableArray      * _uriArray;
    //    NSMutableDictionary * _uriDictionary;
}

-(void) addContact:(Contact*) contact;
-(IBAction) writeData;
-(IBAction) readData;
-(IBAction) clearUIData;
@end

ViewController* vc;