//
//  ContactDB.h
//  CoreData-sqlite3
//
//  Created by guoxiaodong on 13-6-4.
//  Copyright (c) 2013年 chinasofti. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "sqlite3.h"
#define FILE_NAME_CONTACTLIST_DB @"conatct.db"

@interface ContactDB : NSObject
{
    sqlite3*          _dataBase;
}
-(void)save:(NSMutableArray*) aContactArray;
-(void)loadContact;
@end
