//
//  ContactInfo.m 
//
//  Created by  lina on 2011-5-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Contact.h"
//#import "API.h"
//#import "PinyinConverter.h"
//#import "CoreFetion4.h"
//#import "SearchDB.h"

#pragma mark -
#pragma mark contant
// contactlist
#define KEY_CONTACT_USERID @"userID"
#define KEY_CONTACT_LOCALNAME @"localName"
#define KEY_CONTACT_URI	@"uri"
#define KEY_CONTACT_GROUPID @"groupID"
#define KEY_CONTACT_ONLINENOTIFY @"onlineNotify"
#define KEY_CONTACT_BLOCKED	@"blocked"
#define KEY_CONTACT_TYPE @"type"
#define KEY_CONTACT_RELATIONSTATUS @"relationStatus"
#define KEY_CONTACT_PERMISSION_SHOWPRESENCE @"showPresence"
#define KEY_CONTACT_PERMISSION_SHOWNAMEMOBILE @"showNameMobile"
#define KEY_CONTACT_PERMISSION_SHOWBIRTHDAY @"showBirthday"
#define KEY_CONTACT_PERMISSION_SHOWEMAIL @"showEmail"
#define KEY_CONTACT_PERMISSION_SHOWPHONE @"showPhone"

// presence
#define KEY_CONTACT_SID @"sid"
#define KEY_CONTACT_NICKNAME @"nickName"
#define KEY_CONTACT_IMPRESE @"impresa"
#define KEY_CONTACT_PORTRAITCRC @"portraitCrc"
#define KEY_CONTACT_MOBILENUMBER @"mobileNumber"
#define KEY_CONTACT_ISMEMBER @"isMember"
#define KEY_CONTACT_ISSMSONLINE @"isSmsOnline"

#define KEY_CONTACT_DEVICECAPS @"deviceCaps"
#define KEY_CONTACT_CARRIER @"carrier"
#define KEY_CONTACT_CARRIERSTATUS @"carrierStatus"
#define KEY_CONTACT_BASICSERVICESTATUS @"basicServiceStatus"
#define KEY_CONTACT_STATE @"state"
#define KEY_CONTACT_DEVICETYPE @"deviceType"

#define KEY_CONTACT_SORT_KEY @"sortKey"

#pragma mark -

@implementation Contact

@synthesize userID,uri,groupID,onlineNotify,type,relationStatus;	
@synthesize sid,impresa,portraitCrc,mobileNumber,deviceCaps,carrier,isMember;		 
@synthesize isSmsOnline,carrierStatus,basicServiceStatus,state,deviceType,blocked,pushdeviceType;
@synthesize /*contactProfile,*/searchMatching;
@synthesize dbID = dbID;

@synthesize birthdayPermission,mobilePermission,mailPermission,presencePermission;

@synthesize sortKey = _sortKey;

- (void)initializeFromContactList
{
	userID = nil;
	localName = nil;
	uri = nil;
	self.groupID = [NSMutableArray arrayWithCapacity:1];
	onlineNotify = YES;
	blocked = NO;
	type = EUserErr;
	relationStatus = ENotFind;
    
    birthdayPermission = YES;
    mailPermission = YES;
    mobilePermission = NO;
    presencePermission = YES;
    
	
}

- (void)initializeFromPresence
{
	sid = nil;	
	nickName = nil;
	impresa = nil;
	portraitCrc = nil;
	mobileNumber = nil;
	deviceCaps = nil;				
	carrier = nil;					
	
	isMember = NO;
	isSmsOnline = NO;		
	carrierStatus = ENormal;
	basicServiceStatus = EOpen;
	state = EBasicValueOffline;
	deviceType = EBasicDeviceTypes_Unknown;
	pushdeviceType = EBasicPushDeviceTypes_Unknown;
	//self.contactProfile = nil;
}

- (id)init
{
	if (self = [super init])
	{
		[self initializeFromContactList];
		[self initializeFromPresence];
	}
	return self;
}

- (void)dealloc
{
	[userID     release];
	[localName  release];
	[uri        release];
	[groupID    release];
	[sid        release];	
	[nickName   release];
	[impresa    release];
	[portraitCrc release];
	[mobileNumber release];
	[deviceCaps release];				
	[carrier    release];					
	//[contactProfile release];
	//[portrait release];
    [_sortKey   release];
    // [self removeObserver:[CoreFetion sharedCore].contactManager forKeyPath:@"relationStatus"];
    
    
	[super dealloc];
}

- (void)assignContact:(Contact*)theContact
{
    self.userID         = theContact.userID;
    self.uri            = theContact.uri;
    self.localName      = theContact.localName;
    self.groupID        = theContact.groupID;
    onlineNotify        = theContact.onlineNotify;
    blocked             = theContact.blocked;
    type                = theContact.type;
    relationStatus      = theContact.relationStatus;
    self.sid            = theContact.sid;
    self.nickName       = theContact.nickName;
    self.impresa        = theContact.impresa;
    self.portraitCrc    = theContact.portraitCrc;
    self.mobileNumber   = theContact.mobileNumber;
    self.deviceCaps     = theContact.deviceCaps;				
    self.carrier        = theContact.carrier;	
    self.sortKey        = theContact.sortKey;
    isMember            = theContact.isMember;
    isSmsOnline         = theContact.isSmsOnline;
    carrierStatus       = theContact.carrierStatus;
    basicServiceStatus  = theContact.basicServiceStatus;
    state               = theContact.state;
    deviceType          = theContact.deviceType;
    pushdeviceType      = theContact.pushdeviceType;
    birthdayPermission  = theContact.birthdayPermission;
    mailPermission      = theContact.mailPermission;
    mobilePermission    = theContact.mobilePermission;
    presencePermission  = theContact.presencePermission;
//    if (contactProfile == nil) 
//    {
//        contactProfile = [[ContactProfile alloc] init];
//    }
//    [contactProfile assignProfile:theContact.contactProfile];
}

- (id)initWithCoder:(NSCoder*)aDecoder 
{
    self = [super init];
    if(self != nil)
	{
		self.userID             = [aDecoder decodeObjectForKey:KEY_CONTACT_USERID];
		localName               = [aDecoder decodeObjectForKey:KEY_CONTACT_LOCALNAME];[localName retain];
		self.uri                = [aDecoder decodeObjectForKey:KEY_CONTACT_URI];
		//self.groupID = [aDecoder decodeObjectForKey:KEY_CONTACT_GROUPID];
		self.onlineNotify       = [aDecoder decodeBoolForKey:KEY_CONTACT_ONLINENOTIFY];
		self.blocked            = [aDecoder decodeBoolForKey:KEY_CONTACT_BLOCKED];
		self.type               = [aDecoder decodeIntForKey:KEY_CONTACT_TYPE];
		self.relationStatus     = [aDecoder decodeIntForKey:KEY_CONTACT_RELATIONSTATUS];
		presencePermission      = [aDecoder decodeBoolForKey:KEY_CONTACT_PERMISSION_SHOWPRESENCE];
        birthdayPermission      = [aDecoder decodeBoolForKey:KEY_CONTACT_PERMISSION_SHOWBIRTHDAY];
		mailPermission          = [aDecoder decodeBoolForKey:KEY_CONTACT_PERMISSION_SHOWEMAIL];
		mobilePermission        = [aDecoder decodeBoolForKey:KEY_CONTACT_PERMISSION_SHOWPHONE];
		nickName                = [aDecoder decodeObjectForKey:KEY_CONTACT_NICKNAME];[nickName retain];
		self.impresa            = [aDecoder decodeObjectForKey:KEY_CONTACT_IMPRESE];
		self.portraitCrc        = [aDecoder decodeObjectForKey:KEY_CONTACT_PORTRAITCRC];
        self.mobileNumber       = [aDecoder decodeObjectForKey:KEY_CONTACT_MOBILENUMBER];
		self.isMember           = [aDecoder decodeBoolForKey:KEY_CONTACT_ISMEMBER];
		self.isSmsOnline        = [aDecoder decodeBoolForKey:KEY_CONTACT_ISSMSONLINE];
        self.deviceCaps         = [aDecoder decodeObjectForKey:KEY_CONTACT_DEVICECAPS];
        self.carrier            = [aDecoder decodeObjectForKey:KEY_CONTACT_CARRIER];
        self.carrierStatus      = [aDecoder decodeIntForKey:KEY_CONTACT_CARRIERSTATUS];
        self.basicServiceStatus = [aDecoder decodeIntForKey:KEY_CONTACT_BASICSERVICESTATUS];
        self.sid                = [aDecoder decodeObjectForKey:KEY_CONTACT_SID];
		self.sortKey            = [aDecoder decodeObjectForKey:KEY_CONTACT_SORT_KEY];
        self.state              = EBasicValueOffline;
        self.deviceType         = EBasicDeviceTypes_Unknown;
        self.pushdeviceType     = EBasicPushDeviceTypes_Unknown;
    }
    return self;
}


- (void)encodeWithCoder:(NSCoder *)aCoder 
{
    [aCoder encodeObject:self.userID        forKey:KEY_CONTACT_USERID];
    [aCoder encodeObject:self.localName     forKey:KEY_CONTACT_LOCALNAME];
    [aCoder encodeObject:self.uri           forKey:KEY_CONTACT_URI];    
    //[aCoder encodeObject:self.groupID forKey:KEY_CONTACT_GROUPID];
    [aCoder encodeBool:self.onlineNotify    forKey:KEY_CONTACT_ONLINENOTIFY];
    [aCoder encodeBool:self.blocked         forKey:KEY_CONTACT_BLOCKED];
    [aCoder encodeInteger:self.type         forKey:KEY_CONTACT_TYPE];
    [aCoder encodeInteger:self.relationStatus forKey:KEY_CONTACT_RELATIONSTATUS];
    [aCoder encodeBool:presencePermission   forKey:KEY_CONTACT_PERMISSION_SHOWPRESENCE];
    [aCoder encodeBool:birthdayPermission   forKey:KEY_CONTACT_PERMISSION_SHOWBIRTHDAY];
    [aCoder encodeBool:mailPermission       forKey:KEY_CONTACT_PERMISSION_SHOWEMAIL];
    [aCoder encodeBool:mobilePermission     forKey:KEY_CONTACT_PERMISSION_SHOWPHONE];
    [aCoder encodeObject:self.nickName      forKey:KEY_CONTACT_NICKNAME];
    [aCoder encodeObject:self.impresa       forKey:KEY_CONTACT_IMPRESE];
    [aCoder encodeObject:self.portraitCrc   forKey:KEY_CONTACT_PORTRAITCRC];
    [aCoder encodeObject:self.mobileNumber  forKey:KEY_CONTACT_MOBILENUMBER];
    [aCoder encodeBool:self.isMember        forKey:KEY_CONTACT_ISMEMBER];
    [aCoder encodeBool:self.isSmsOnline     forKey:KEY_CONTACT_ISSMSONLINE];
    [aCoder encodeObject:self.deviceCaps    forKey:KEY_CONTACT_DEVICECAPS];
    [aCoder encodeObject:self.carrier       forKey:KEY_CONTACT_CARRIER];
    [aCoder encodeInt:self.carrierStatus    forKey:KEY_CONTACT_CARRIERSTATUS];
    [aCoder encodeInt:self.basicServiceStatus forKey:KEY_CONTACT_BASICSERVICESTATUS];
    [aCoder encodeObject:self.sid           forKey:KEY_CONTACT_SID];
    [aCoder encodeObject:self.sortKey       forKey:KEY_CONTACT_SORT_KEY];
}
- (NSString *)nickName
{
	return nickName;
}

- (void)setNickName:(NSString *)newNickName
{
	[nickName release];
	nickName = newNickName;
	[nickName retain];
	
//	if(localName == nil || [localName length] == 0)
//	{
//		PinyinConverter * converter = [CoreFetion sharedCore].contactManager.converter;
//		self.sortKey = [converter setUtf8String:newNickName];
//	}
}

- (NSString *)localName
{
	return localName;
}

- (void)setLocalName:(NSString *)newLocalName
{
	[localName release];
	localName = newLocalName;
	[localName retain];
//	if(newLocalName && [newLocalName length] > 0)
//	{
//		PinyinConverter * converter = [CoreFetion sharedCore].contactManager.converter;
//		self.sortKey = [converter setUtf8String:newLocalName];
//	}
//    else {
//        PinyinConverter * converter = [CoreFetion sharedCore].contactManager.converter;
//		self.sortKey = [converter setUtf8String:nickName];
//    }
}

#pragma mark -
#pragma mark member method

//- (NSComparisonResult)comparesearch:(Contact*)theContact
//{
//   // NSLog(@"%@%d%@%d",self.showName,self.searchMatching,[theContact showName],theContact.searchMatching);
//    NSComparisonResult ret = NSOrderedAscending;
//    if (self.searchMatching < theContact.searchMatching) {
//        ret = NSOrderedDescending ;
//    }
//    else
//        ret = NSOrderedAscending ;
//}

/*
 在线
 短信在线
 手机好友
 离线
 待验证
 被拒绝
 */
//在线会员，在线普通好友，短线在线会员，短信在线普通好友，手机好友，离线会员，离线普通好友
- (NSComparisonResult)compare:(Contact*)theContact
{	
	NSComparisonResult ret = NSOrderedAscending;
    if (self.basicServiceStatus == EClose)
    {
        self.pushdeviceType = EBasicPushDeviceTypes_Unknown;
    }
    if (theContact.basicServiceStatus == EClose) 
    {
        theContact.pushdeviceType = EBasicPushDeviceTypes_Unknown;
    }
	if (self.relationStatus == theContact.relationStatus)//不是带验证被拒绝
	{
            if((self.state != EBasicValueOffline || self.pushdeviceType != EBasicPushDeviceTypes_Unknown)
               && (theContact.state != EBasicValueOffline || theContact.pushdeviceType != EBasicPushDeviceTypes_Unknown))//同为在线状态，比较是否是会员
            {
                ret = [self compareMemberState:theContact];
            }
            else if((self.state == EBasicValueOffline && theContact.state != EBasicValueOffline) 
                    ||(self.state != EBasicValueOffline && theContact.state == EBasicValueOffline)
                    || (self.pushdeviceType == EBasicPushDeviceTypes_Unknown && theContact.pushdeviceType != EBasicPushDeviceTypes_Unknown)
                    || (self.pushdeviceType != EBasicPushDeviceTypes_Unknown && theContact.pushdeviceType == EBasicPushDeviceTypes_Unknown)
                    ||(self.state != EBasicValueOffline && theContact.pushdeviceType == EBasicPushDeviceTypes_Unknown)
                    ||(self.state == EBasicValueOffline && theContact.pushdeviceType != EBasicPushDeviceTypes_Unknown))
            {
             
                if (self.state == EBasicValueOffline && self.pushdeviceType == EBasicPushDeviceTypes_Unknown)
                    ret = NSOrderedDescending;
                else
                    ret = NSOrderedAscending;

            }
			else 
            {
                if (self.isSmsOnline == theContact.isSmsOnline) //短信在线状态相同
				{
//                    if ((self.type == ECellFriend && theContact.type == ECellFriend)
//						|| (self.type != ECellFriend && theContact.type != ECellFriend)) //同为手机好友或同时不为手机好友
//					{
//						if (self.type != 2 && theContact.type != 2) //同时不为手机好友,比较是否是会员
//						{
							if ((self.type == 3 && theContact.type == 3)
								|| (self.type != 3 && theContact.type != 3)) //同为陌生人或同时不为陌生人
							{
								ret = [self compareMemberState:theContact];
							}
							else
							{
								if (self.type != 3)
									ret = NSOrderedAscending; //普通好友在前
								else
									ret = NSOrderedDescending; //陌生人在后
							}
						//}
//						else //都是手机好友，比较名称
//						{
//							ret = [self compareName:theContact];
//						}
//					}
//					else //一个手机好友，一个普通好友
//					{
//						if (self.type != ECellFriend)
//							ret = NSOrderedDescending; //普通好友在hou
//						else
//							ret = NSOrderedAscending; //手机好友在qian
//					}
				}
				else //在线状态不相同，短信在线的在前
				{
					if (self.isSmsOnline)
						ret = NSOrderedAscending; //自己在对方之前
					else
						ret = NSOrderedDescending;//自己在对方之后
				}
            }		
	}
	else //好友验证状态不同，比较好友验证状态
	{
		if (self.relationStatus == EConfirmed)
		{
			ret = NSOrderedAscending;
		}
		else if (theContact.relationStatus == EConfirmed)
		{
			ret = NSOrderedDescending;
		}
		else
		{
			ret = self.relationStatus < theContact.relationStatus?NSOrderedAscending:NSOrderedDescending;
		}
	}
	return ret;
}

- (NSComparisonResult)compareMemberState:(Contact*)theContact
{
	NSComparisonResult ret = NSOrderedAscending;
	if (([self isMember] == 0 && [theContact isMember] == 0)
		|| ([self isMember] != 0 && [theContact isMember] != 0)) //同为会员，比较显示名称
	{
		ret = [self compareName:theContact];
	}
	else //一个是会员，一个不是会员
	{
		if ([self isMember] != 0)
			ret = NSOrderedAscending; //会员在前
		else
			ret = NSOrderedDescending; //不是会员在后
	}
	return ret;
}


- (NSComparisonResult)comparePresence:(Contact*)theContact
{
	NSComparisonResult ret = NSOrderedSame;
	if([self isOnline] ^ [theContact isOnline])
	{
		return [self isOnline] ? NSOrderedAscending : NSOrderedDescending;
	}
	else
	{
		if([self isSmsOnline] ^ [theContact isSmsOnline])
		{
			return [self isSmsOnline] ? NSOrderedAscending : NSOrderedDescending;
		}
		else
		{
			if ([self isMember] ^ [theContact isMember])
			{
				ret = [self isMember] ? NSOrderedAscending : NSOrderedDescending;;
			}
		}
	}
	return ret;
}

+ (NSString*)sidFromUri:(NSString*)sid uri:(NSString*)uri
{
    NSString * sid_uri = sid;
    if ( (sid == nil || [sid isEqualToString:@""]) && (uri != nil && ![uri isEqualToString:@"" ]))
    {
        NSRange start = [uri rangeOfString:@":"];
        NSRange end = [uri rangeOfString:@"@"];
        if (start.length <= 0 ) 
        {
            return sid;
        }
        if ( end.length > 0 ) 
        {
            NSRange range = NSMakeRange(start.location+1, end.location-start.location-1);
            sid_uri = [uri substringWithRange:range];
        }
        else
        {
            sid_uri = [uri substringFromIndex:start.location + 1];
        }
    }
    return sid_uri;
}

- (BOOL)isMobileBuddy
{
	return [self.uri hasPrefix:@"tel"];
}

- (NSString *)showName
{
	//当屏显名称显示为空格的时候，要在好友列表以昵称的形式显示
	NSString * showname = [self.localName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	if (showname == nil || [showname isEqualToString:@""])
	{
		showname = [self.nickName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
	}
    if (showname == nil || [showname isEqualToString:@""]) 
    {
#if defined(Urapport)
        NSLog(@"this is Urapport");
        NSString *strTmp = nil;
        strTmp = [Contact sidFromUri:sid uri:uri];
        if([strTmp hasPrefix:@"0084"])
        {
            showname = [strTmp substringFromIndex:4];
            
        }
        else if([strTmp hasPrefix:@"-90084"])
        {
            showname = [strTmp substringFromIndex:5];
            
        }
        else if([strTmp hasPrefix:@"84"])
        {
            showname = [strTmp substringFromIndex:2];
        }
        else
        {
            showname = strTmp;
        }
        
#else
        showname = [Contact sidFromUri:sid uri:uri];
#endif
  
    }

	return showname;
}

- (BOOL)isFetionRobot 
{
	BOOL ret = NO;
	if ( [self.uri rangeOfString:@"t=robot"].location != NSNotFound && (self.state == EBasicValueRobot))
	{
		ret = YES;
	}
	return ret;
}

- (BOOL) isFCContact
{
    BOOL ret = NO;
	if ( self.deviceType == EBasicDeviceTypes_FC)
	{
		ret = YES;
	}
	return ret;
}

- (BOOL)isOnline
{
    BOOL ret = NO;
    if ((self.basicServiceStatus == EOpen && self.state != EBasicValueOffline) || (self.state == EBasicValueOffline && self.deviceType == EBasicDeviceTypes_Unknown && self.pushdeviceType != EBasicPushDeviceTypes_Unknown))
    {
        ret = YES;
    }
    return ret;
}

- (BOOL)canReceiveSms
{
//    if (self.relationStatus == EConfirmed && self.blocked == NO && ((self.type == EFriend && self.isSmsOnline)|| self.type == ECellFriend)  && self.deviceType != EBasicDeviceTypes_Robot && [CoreFetion sharedCore].isCMCC)
//    {
//        return YES;
//    }
    return NO;
    
}

- (BOOL)availableForChat
{
    if (self.basicServiceStatus == EOpen && self.relationStatus == EConfirmed && self.blocked == NO && self.type == EFriend)
    {
        return YES;
    }
    return NO;
}

- (NSInteger)deviceCapsValue
{
    NSInteger len = [self.deviceCaps length];
    NSString * capsString = [self.deviceCaps uppercaseString];
    int retValue = 0x0;
    for (NSInteger index = 0; index < len; ++index) {
        unichar c = [capsString characterAtIndex:index];
        c = c <= '9' ? c - '0' : c - 'A' + 10;
        retValue <<= 4;
        retValue |= c;
    }
    return retValue;
}

- (BOOL)supportSimpleIm
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x01) == 0x01 )?YES:NO; // bit0
	return ret;
}
- (BOOL)supportImSession
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x02) == 0x02 )?YES:NO; // bit1
	return ret;
}

- (BOOL)supportTempGroup 
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x04) == 0x04 )?YES:NO; // bit2
	return ret;	
}
- (BOOL)supportPoc
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x08) == 0x08 )?YES:NO; // bit3
	return ret;
	
}
- (BOOL)supportPersonalGroup
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x10) == 0x10 )?YES:NO; // bit4
	return ret;
	
}
- (BOOL)supportXenoIm
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x20) == 0x20 )?YES:NO; // bit5
	return ret;
	
}
- (BOOL)supportDirectSms
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x40) == 0x40 )?YES:NO; // bit6
	return ret;
	
}
- (BOOL)supportSms2Fetion
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x80) == 0x80 )?YES:NO; // bit7
	return ret;
}

- (BOOL)supportImRelay
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x01) == 0x01 )?YES:NO; // bit8
	return ret;
}
- (BOOL)supportRtm
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x02) == 0x02 ) ? YES:NO;// bit9
	return ret;
}
- (BOOL)supportMultiClient
{
	BOOL ret = NO;
	NSInteger caps = [self deviceCapsValue];
	ret = ( (caps & 0x04) == 0x04 )?YES:NO; // bit10
	return ret;
}
@end