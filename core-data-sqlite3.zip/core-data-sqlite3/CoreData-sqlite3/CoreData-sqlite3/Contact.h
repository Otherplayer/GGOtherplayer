//
//  ContactInfo.h 
//
//  Created by  lina on 2011-5-26.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "ContactProfile.h"
//#import "Profile.h"
//#import "FetionAppDelegate.h"


typedef enum 
{
    EUserErr     = 0, //可能认识的人
	EFriend      = 1, //好友
	ECellFriend  = 2, //手机号 －－ 没开通飞信
	EChatFriend  = 3, //陌生人
	EDeleted   = 4,  //删除并阻止 －－ 不在好友列表中
    EPPContact =5
	
} ContactType;

typedef enum
{
    ENotFind    = -1,  //未查到状态
	ENotConfirm = 0,   //未确认
	EConfirmed  = 1,   //已经确认
	ERefused    = 2    //被拒绝
	
} ContactRelationStatus;

typedef enum
{
	ENormal            = 0,   //正常
	EOutOfService      = 1,   //停机
	EDeletePhoneNumber = 2    //注销
	
} CarrierStatus;

typedef enum
{
	EClose  = 0,   //关闭
	EOpen   = 1    //开通
	
} BasicServiceStatus;

typedef enum     
{
    EBasicValueUnknown	= -1,
//    EBasicValueMeeting	= 850,     
//    EBasicValueNoBreak	= 800,    
    EBasicValueBusy		= 600,   
//    EBasicValuePhone	= 500,
	EBasicValueRobot	= 499,
    EBasicValueOnline	= 400,      
//    EBasicValueBackSoon = 300,       
//    EBasicValueRepast	= 150,      
    EBasicValueLeave	= 100,       
    EBasicValueOffline	= 0      
	
}  BasicPresenceValue;

typedef enum 
{
	EBasicDeviceTypes_Unknown = 0,
    EBasicDeviceTypes_Mobile = 1,
    EBasicDeviceTypes_PC = 2,
    EBasicDeviceTypes_Robot = 3,
    EBasicDeviceTypes_WapWeb = 4,
    EBasicDeviceTypes_FC = 5
	
} BasicDeviceTypes;

typedef enum 
{
	EBasicPushDeviceTypes_Unknown = 0,
    EBasicPushDeviceTypes_Mobile = 1,
    EBasicPushDeviceTypes_PC = 2
	
} BasicPushDeviceTypes;

@interface Contact : NSObject<NSCoding>
{
	// from contact list : 9
    int        dbID;
	NSString * userID;
	NSString * localName;
	NSString * uri;
	NSMutableArray  * groupID;// NSString
	BOOL       onlineNotify;
	BOOL	   blocked;
	ContactType				type;
	ContactRelationStatus   relationStatus;
    
    BOOL       birthdayPermission;
    BOOL       mailPermission;
    BOOL       mobilePermission; // indentity
    BOOL       presencePermission;
	
	// from presence
	NSString * sid;	
	NSString * nickName;//存储好友姓名
	NSString * impresa;//存储心情短语
	NSString * portraitCrc;
	NSString * mobileNumber;
	NSString * deviceCaps;				
	NSString * carrier;						// 运营商

	BOOL				isMember;			//services
	BOOL				isSmsOnline;		//是否接收短信		
	CarrierStatus		carrierStatus;
	BasicServiceStatus	basicServiceStatus;
	BasicPresenceValue	state;
	BasicDeviceTypes	deviceType;
	BasicPushDeviceTypes pushdeviceType;
	// contact t
	//ContactProfile *	    contactProfile;
	
	NSString * _sortKey;
	
    NSInteger searchMatching;
}
@property (nonatomic)   int dbID;
@property (nonatomic, retain) NSString * userID;
@property (nonatomic, retain) NSString * localName;
@property (nonatomic, retain) NSString * uri;
@property (nonatomic, retain) NSMutableArray  * groupID;
@property (nonatomic,assign)  BOOL              onlineNotify;
@property (nonatomic,assign)  BOOL              blocked;
@property (nonatomic) ContactType		 type;
@property (nonatomic) ContactRelationStatus    relationStatus;
@property (nonatomic, retain) NSString * sid;	
@property (nonatomic, retain) NSString * nickName;
@property (nonatomic, retain) NSString * impresa;
@property (nonatomic, retain) NSString * portraitCrc;
@property (nonatomic, retain) NSString * mobileNumber;
@property (nonatomic, retain) NSString * deviceCaps;
@property (nonatomic, retain) NSString * carrier;
@property (nonatomic) BOOL				 isMember;		 
@property (nonatomic) BOOL				 isSmsOnline;	
@property (nonatomic) CarrierStatus		 carrierStatus;
@property (nonatomic) BasicServiceStatus basicServiceStatus;
@property (nonatomic) BasicPresenceValue state;			
@property (nonatomic) BasicDeviceTypes	 deviceType;
@property (nonatomic) BasicPushDeviceTypes pushdeviceType;
//@property (nonatomic, retain) ContactProfile *  contactProfile;
@property (nonatomic, assign) BOOL       birthdayPermission;
@property (nonatomic, assign) BOOL       mobilePermission;
@property (nonatomic, assign) BOOL       mailPermission;
@property (nonatomic, assign) BOOL       presencePermission;
@property (nonatomic,assign) NSInteger searchMatching;
@property (nonatomic, retain) NSString * sortKey;

- (void)initializeFromContactList;
- (void)initializeFromPresence;

- (BOOL)isOnline;
- (BOOL)canReceiveSms;
- (BOOL)availableForChat;

- (void)assignContact:(Contact*)theContact;

- (NSComparisonResult)compare:(Contact*)aContract;
- (NSComparisonResult)compareMemberState:(Contact*)theContact;
- (NSComparisonResult)compareName:(Contact*)theContact;
- (NSComparisonResult)comparePresence:(Contact*)theContact;
// device caps
- (NSInteger)deviceCapsValue;
- (BOOL)supportSimpleIm;	//一对一的无会话消息 bit0
- (BOOL)supportImSession;	//一对一即时消息会话,bit1
- (BOOL)supportTempGroup ;	// 基于临时群组的多人即时会话bit2
- (BOOL)supportPoc;			//是否支持PoC bit3
- (BOOL)supportPersonalGroup;//个人群组 bit4
- (BOOL)supportXenoIm;		//陌生人会话（验证陌生人能力）bit5
- (BOOL)supportDirectSms;	//直接短信bit6
- (BOOL)supportSms2Fetion;	//短信飞转bit7
- (BOOL)supportImRelay;		//集中会话模式(基于V3架构的会话能力) bit8
- (BOOL)supportRtm;			//音视频会话（Real-Time Media）bit9
- (BOOL)supportMultiClient; //多点登录bit10

- (NSString*)showName;   
- (BOOL)isFetionRobot;
+ (NSString*)sidFromUri:(NSString*)sid uri:(NSString*)uri;

- (BOOL) isMobileBuddy;
- (BOOL) isFCContact;

-(NSArray*) _generateStringKey:(NSString*) name dataSourceIndex:(NSString*) index;
-(void) generateContactKey:(Contact*) aContact keyAry:(NSMutableArray*) keyArray;

@end